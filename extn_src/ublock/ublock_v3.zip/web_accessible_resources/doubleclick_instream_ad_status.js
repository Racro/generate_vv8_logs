window.google_ad_status = 1;
